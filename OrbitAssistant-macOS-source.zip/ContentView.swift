import AppKit
import SwiftUI

struct ContentView: View {
    @ObservedObject var model: OrbitModel
    @State private var draft = ""
    @State private var showingSettings = false

    var body: some View {
        HStack(spacing: 0) {
            sidebar
            Divider()
            mainPanel
        }
        .background(Color(NSColor.windowBackgroundColor))
        .sheet(isPresented: $showingSettings) { SettingsView(model: model) }
        .alert(isPresented: Binding(get: { model.errorMessage != nil }, set: { if !$0 { model.errorMessage = nil } })) {
            Alert(title: Text("Orbit Assistant"), message: Text(model.errorMessage ?? "Something went wrong."), dismissButton: .default(Text("OK")))
        }
    }

    private var sidebar: some View {
        VStack(alignment: .leading, spacing: 12) {
            HStack {
                Text("Chats").font(.headline)
                Spacer()
                Button(action: model.createConversation) { Image(systemName: "square.and.pencil") }
                    .buttonStyle(PlainButtonStyle()).help("New chat")
            }.padding(.horizontal, 14).padding(.top, 18)
            ScrollView {
                VStack(spacing: 4) {
                    ForEach(model.conversations) { conversation in
                        Button(action: { model.selectConversation(conversation.id) }) {
                            HStack {
                                Text(conversation.title).lineLimit(1)
                                Spacer(minLength: 0)
                            }
                            .padding(.vertical, 9).padding(.horizontal, 10)
                            .background(conversation.id == model.activeConversationID ? Color.accentColor.opacity(0.18) : Color.clear)
                            .cornerRadius(8)
                        }
                        .buttonStyle(PlainButtonStyle())
                    }
                }.padding(.horizontal, 8)
            }
            Spacer(minLength: 0)
            Button(action: { showingSettings = true }) {
                HStack { Image(systemName: "gearshape"); Text("Settings") }
                    .frame(maxWidth: .infinity, alignment: .leading)
                    .padding(12)
            }.buttonStyle(PlainButtonStyle())
        }
        .frame(width: 220)
        .background(Color(NSColor.controlBackgroundColor))
    }

    private var mainPanel: some View {
        VStack(spacing: 0) {
            HStack {
                VStack(alignment: .leading, spacing: 3) {
                    Text("Orbit Assistant").font(.headline)
                    Text(model.voiceStatus.isEmpty ? model.status : model.voiceStatus)
                        .font(.caption).foregroundColor(.secondary).lineLimit(1)
                }
                Spacer()
                Button(action: { showingSettings = true }) { Image(systemName: "gearshape") }
                    .buttonStyle(PlainButtonStyle()).help("Settings")
            }
            .padding(.horizontal, 20).padding(.vertical, 14)
            Divider()
            ScrollView {
                VStack(alignment: .leading, spacing: 15) {
                    if let conversation = model.activeConversation, conversation.messages.isEmpty {
                        welcome
                    }
                    if let conversation = model.activeConversation {
                        ForEach(conversation.messages) { message in messageView(message) }
                    }
                    if model.isBusy { Text("Orbit is thinking…").font(.caption).foregroundColor(.secondary).frame(maxWidth: .infinity, alignment: .leading) }
                }
                .padding(20)
            }
            Divider()
            inputArea.padding(14)
        }
    }

    private var welcome: some View {
        VStack(alignment: .leading, spacing: 8) {
            Text("Your desktop sidekick").font(.title2).fontWeight(.semibold)
            Text("Ask questions, attach images or documents, or start a live voice conversation.")
                .foregroundColor(.secondary)
            Text("Configure an OpenAI API key or a local Ollama model in Settings to get started.")
                .font(.caption).foregroundColor(.secondary)
        }
        .padding(18).frame(maxWidth: .infinity, alignment: .leading)
        .background(Color.accentColor.opacity(0.08)).cornerRadius(12)
    }

    private func messageView(_ message: OrbitMessage) -> some View {
        HStack {
            if message.role == "assistant" { messageBubble(message, user: false); Spacer(minLength: 40) }
            else { Spacer(minLength: 40); messageBubble(message, user: true) }
        }
    }

    private func messageBubble(_ message: OrbitMessage, user: Bool) -> some View {
        VStack(alignment: .leading, spacing: 7) {
            Text(user ? "YOU" : "ORBIT").font(.caption2).fontWeight(.bold).foregroundColor(user ? Color.accentColor : Color.secondary)
            if !message.text.isEmpty { Text(message.text).fixedSize(horizontal: false, vertical: true) }
            ForEach(message.attachments) { attachment in
                if attachment.isImage, let encoded = attachment.base64, let data = Data(base64Encoded: encoded), let image = NSImage(data: data) {
                    Image(nsImage: image).resizable().aspectRatio(contentMode: .fit).frame(maxHeight: 220).cornerRadius(8)
                } else {
                    HStack { Image(systemName: attachment.mimeType == "application/pdf" ? "doc.text" : "paperclip"); Text(attachment.name) }
                        .font(.caption).foregroundColor(.secondary)
                }
            }
        }
        .padding(12).background(user ? Color.accentColor.opacity(0.12) : Color(NSColor.controlBackgroundColor))
        .cornerRadius(12).frame(maxWidth: 520, alignment: .leading)
    }

    private var inputArea: some View {
        VStack(alignment: .leading, spacing: 9) {
            if !model.pendingAttachments.isEmpty {
                ScrollView(.horizontal, showsIndicators: false) {
                    HStack {
                        ForEach(model.pendingAttachments) { item in
                            HStack(spacing: 6) {
                                Text(item.name).lineLimit(1).frame(maxWidth: 160)
                                Button(action: { model.removeAttachment(item) }) { Image(systemName: "xmark.circle.fill") }.buttonStyle(PlainButtonStyle())
                            }.padding(6).background(Color(NSColor.controlBackgroundColor)).cornerRadius(7)
                        }
                    }
                }
            }
            HStack(spacing: 9) {
                TextField("Message Orbit…", text: $draft, onCommit: send)
                    .textFieldStyle(RoundedBorderTextFieldStyle())
                    .disabled(model.isBusy || !model.voiceStatus.isEmpty)
                Button(action: chooseAttachments) { Image(systemName: "paperclip") }
                    .help("Attach images or documents")
                Button(action: { model.startVoice() }) {
                    Image(systemName: model.voiceStatus.isEmpty ? "mic" : "stop.fill")
                }.help(model.voiceStatus.isEmpty ? "Start live voice" : "Stop live voice")
                Button(action: send) { Image(systemName: "arrow.up.circle.fill").font(.title2) }
                    .disabled(model.isBusy || (draft.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty && model.pendingAttachments.isEmpty))
            }
            Text("Images and document text are sent to your selected provider. Voice streams microphone audio to OpenAI while active.")
                .font(.caption2).foregroundColor(.secondary).frame(maxWidth: .infinity, alignment: .center)
        }
    }

    private func send() {
        let message = draft
        draft = ""
        model.send(message)
    }

    private func chooseAttachments() {
        let panel = NSOpenPanel()
        panel.title = "Attach images or documents"
        panel.canChooseFiles = true
        panel.canChooseDirectories = false
        panel.allowsMultipleSelection = true
        panel.allowedFileTypes = ["png", "jpg", "jpeg", "webp", "txt", "md", "csv", "json", "log", "xml", "html", "htm", "pdf"]
        if panel.runModal() == .OK { model.addAttachments(from: panel.urls) }
    }
}
