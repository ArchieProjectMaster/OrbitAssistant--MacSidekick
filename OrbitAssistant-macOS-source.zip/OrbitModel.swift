import AppKit
import Combine
import Foundation
import PDFKit
import Security

struct OrbitAttachment: Codable, Identifiable {
    var id = UUID()
    var name: String
    var mimeType: String
    var base64: String?
    var extractedText: String?

    var isImage: Bool { base64 != nil }
    var byteCount: Int { base64.map { Data(base64Encoded: $0)?.count ?? 0 } ?? (extractedText?.utf8.count ?? 0) }
}

struct OrbitMessage: Codable, Identifiable {
    var id = UUID()
    var role: String
    var text: String
    var attachments: [OrbitAttachment] = []
}

struct OrbitConversation: Codable, Identifiable {
    var id = UUID()
    var title: String
    var updatedAt = Date()
    var messages: [OrbitMessage] = []
}

final class OrbitModel: ObservableObject {
    @Published var conversations: [OrbitConversation] = []
    @Published var activeConversationID: UUID?
    @Published var pendingAttachments: [OrbitAttachment] = []
    @Published var isBusy = false
    @Published var status = "Ready when you are"
    @Published var errorMessage: String?
    @Published var voiceStatus = ""
    @Published var provider = UserDefaults.standard.string(forKey: "provider") ?? "openai"
    @Published var modelName = UserDefaults.standard.string(forKey: "model") ?? "gpt-6-luna"
    @Published var endpoint = UserDefaults.standard.string(forKey: "endpoint") ?? "http://localhost:11434/v1/chat/completions"
    @Published var theme = UserDefaults.standard.string(forKey: "theme") ?? "system"
    @Published var apiKey = KeychainStore.read() ?? ""

    private let fileURL: URL
    private var voice: RealtimeVoiceService?
    private let systemPrompt = "You are Orbit, a warm and capable macOS desktop assistant. Be concise, useful, and honest. You can answer questions, analyze attached images and documents, and help the user use their Mac. Do not claim to control the computer or perform an action unless the app reports that it succeeded."

    init() {
        let base = FileManager.default.urls(for: .applicationSupportDirectory, in: .userDomainMask).first!
        let directory = base.appendingPathComponent("OrbitAssistant", isDirectory: true)
        try? FileManager.default.createDirectory(at: directory, withIntermediateDirectories: true, attributes: nil)
        fileURL = directory.appendingPathComponent("chats.json")
        loadConversations()
        if let first = conversations.sorted(by: { $0.updatedAt > $1.updatedAt }).first {
            activeConversationID = first.id
        } else {
            createConversation()
        }
    }

    var activeConversation: OrbitConversation? {
        conversations.first(where: { $0.id == activeConversationID })
    }

    func saveSettings() {
        stopVoice()
        UserDefaults.standard.set(provider, forKey: "provider")
        UserDefaults.standard.set(modelName, forKey: "model")
        UserDefaults.standard.set(endpoint, forKey: "endpoint")
        UserDefaults.standard.set(theme, forKey: "theme")
        KeychainStore.write(apiKey)
        status = provider == "ollama" ? "Local · \(modelName)" : "OpenAI · \(modelName)"
    }

    func createConversation() {
        stopVoice()
        let conversation = OrbitConversation(title: "New chat")
        conversations.insert(conversation, at: 0)
        activeConversationID = conversation.id
        persist()
    }

    func selectConversation(_ id: UUID) { if id != activeConversationID { stopVoice(); activeConversationID = id } }

    func addAttachments(from urls: [URL]) {
        do {
            let fresh = try urls.map(loadAttachment)
            guard pendingAttachments.count + fresh.count <= 10 else { throw OrbitError.message("Attach up to 10 files to one message.") }
            guard pendingAttachments.reduce(0, { $0 + $1.byteCount }) + fresh.reduce(0, { $0 + $1.byteCount }) <= 20 * 1024 * 1024 else {
                throw OrbitError.message("Attachments must total 20 MB or less.")
            }
            guard pendingAttachments.reduce(0, { $0 + ($1.extractedText?.count ?? 0) }) + fresh.reduce(0, { $0 + ($1.extractedText?.count ?? 0) }) <= 200_000 else {
                throw OrbitError.message("Extracted document text must total 200,000 characters or less.")
            }
            pendingAttachments.append(contentsOf: fresh)
        } catch { errorMessage = error.localizedDescription }
    }

    func removeAttachment(_ attachment: OrbitAttachment) {
        pendingAttachments.removeAll(where: { $0.id == attachment.id })
    }

    func send(_ prompt: String) {
        let text = prompt.trimmingCharacters(in: .whitespacesAndNewlines)
        guard !text.isEmpty || !pendingAttachments.isEmpty else { return }
        guard !isBusy else { return }
        if text.hasPrefix("/"), runLocalCommand(text) { return }
        guard let conversationID = activeConversationID else { return }

        let attachments = pendingAttachments
        pendingAttachments.removeAll()
        let displayText = attachments.isEmpty ? text : text + "\n" + attachments.map { "[Attached: \($0.name)]" }.joined(separator: "\n")
        append(OrbitMessage(role: "user", text: displayText, attachments: attachments), to: conversationID)
        isBusy = true
        status = "Thinking…"
        requestAssistant(conversationID: conversationID)
    }

    private func requestAssistant(conversationID: UUID) {
        guard let conversation = conversations.first(where: { $0.id == conversationID }) else { finish(statusText: "Ready"); return }
        if provider == "openai" && apiKey.trimmingCharacters(in: .whitespacesAndNewlines).isEmpty {
            finish(statusText: "Set up an AI provider in Settings")
            errorMessage = "Add an OpenAI API key in Settings to send AI chat messages."
            return
        }
        guard let url = URL(string: provider == "ollama" ? endpoint : "https://api.openai.com/v1/chat/completions") else {
            finish(statusText: "Check settings")
            errorMessage = "The provider endpoint is not a valid URL."
            return
        }

        var messages: [[String: Any]] = [["role": "system", "content": systemPrompt]]
        messages.append(contentsOf: conversation.messages.map(apiMessage))
        let body: [String: Any] = ["model": modelName, "messages": messages, "stream": false]
        var request = URLRequest(url: url)
        request.httpMethod = "POST"
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        if provider == "openai" { request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization") }
        request.httpBody = try? JSONSerialization.data(withJSONObject: body, options: [.fragmentsAllowed])

        URLSession.shared.dataTask(with: request) { [weak self] data, response, error in
            DispatchQueue.main.async {
                guard let self = self else { return }
                if let error = error { self.finish(statusText: "Connection error"); self.errorMessage = error.localizedDescription; return }
                guard let data = data else { self.finish(statusText: "No response"); return }
                if let http = response as? HTTPURLResponse, !(200...299).contains(http.statusCode) {
                    let payload = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any]
                    let providerError = (payload?["error"] as? [String: Any])?["message"] as? String
                    self.finish(statusText: "Provider error")
                    self.errorMessage = providerError ?? "Provider returned HTTP \(http.statusCode)."
                    return
                }
                do {
                    let payload = try JSONSerialization.jsonObject(with: data) as? [String: Any]
                    let choices = payload?["choices"] as? [[String: Any]]
                    let message = choices?.first?["message"] as? [String: Any]
                    let reply = message?["content"] as? String ?? "The provider returned an empty response."
                    self.append(OrbitMessage(role: "assistant", text: reply), to: conversationID)
                    self.finish(statusText: self.provider == "ollama" ? "Local · \(self.modelName)" : "OpenAI · \(self.modelName)")
                } catch {
                    self.finish(statusText: "Invalid response")
                    self.errorMessage = error.localizedDescription
                }
            }
        }.resume()
    }

    private func apiMessage(_ message: OrbitMessage) -> [String: Any] {
        let images = message.attachments.filter(\.isImage)
        let documents = message.attachments.compactMap { attachment -> String? in
            guard let text = attachment.extractedText, !text.isEmpty else { return nil }
            return "\n\nDocument: \(attachment.name)\n\(text)"
        }.joined()
        let fullText = message.text + documents
        guard !images.isEmpty else { return ["role": message.role, "content": fullText] }
        var content: [[String: Any]] = [["type": "text", "text": fullText.isEmpty ? "Please analyze the attached image." : fullText]]
        for image in images {
            if let base64 = image.base64 {
                content.append(["type": "image_url", "image_url": ["url": "data:\(image.mimeType);base64,\(base64)"]])
            }
        }
        return ["role": message.role, "content": content]
    }

    private func append(_ message: OrbitMessage, to conversationID: UUID) {
        guard let index = conversations.firstIndex(where: { $0.id == conversationID }) else { return }
        conversations[index].messages.append(message)
        conversations[index].updatedAt = Date()
        if conversations[index].title == "New chat", message.role == "user" {
            let firstLine = message.text.components(separatedBy: .newlines).first ?? message.text
            conversations[index].title = String(firstLine.prefix(48))
        }
        conversations.sort(by: { $0.updatedAt > $1.updatedAt })
        persist()
    }

    private func finish(statusText: String) { isBusy = false; status = statusText }

    private func runLocalCommand(_ text: String) -> Bool {
        let parts = text.split(separator: " ", maxSplits: 1).map(String.init)
        let command = parts.first?.lowercased() ?? ""
        let argument = parts.count > 1 ? parts[1] : ""
        switch command {
        case "/help":
            append(OrbitMessage(role: "assistant", text: "Local commands: /help, /open safari|notes|calculator, /system, /web search terms"), to: activeConversationID ?? UUID())
        case "/open":
            let appName = argument.lowercased()
            let appURL: URL? = appName.contains("safari") ? URL(fileURLWithPath: "/Applications/Safari.app") : (appName.contains("notes") ? URL(fileURLWithPath: "/System/Applications/Notes.app") : (appName.contains("calculator") ? URL(fileURLWithPath: "/System/Applications/Calculator.app") : nil))
            if let appURL = appURL { NSWorkspace.shared.open(appURL); append(OrbitMessage(role: "assistant", text: "Opened \(appURL.deletingPathExtension().lastPathComponent)."), to: activeConversationID ?? UUID()) }
            else { append(OrbitMessage(role: "assistant", text: "Supported apps: Safari, Notes, and Calculator."), to: activeConversationID ?? UUID()) }
        case "/system":
            let version = ProcessInfo.processInfo.operatingSystemVersionString
            append(OrbitMessage(role: "assistant", text: "macOS \(version); device \(Host.current().localizedName ?? "Mac")."), to: activeConversationID ?? UUID())
        case "/web":
            guard var components = URLComponents(string: "https://www.google.com/search") else { return true }
            components.queryItems = [URLQueryItem(name: "q", value: argument)]
            if let url = components.url { NSWorkspace.shared.open(url); append(OrbitMessage(role: "assistant", text: "Opened a web search for: \(argument)"), to: activeConversationID ?? UUID()) }
        default: return false
        }
        return true
    }

    private func loadAttachment(_ url: URL) throws -> OrbitAttachment {
        let ext = url.pathExtension.lowercased()
        let imageTypes = ["png", "jpg", "jpeg", "webp"]
        let textTypes = ["txt", "md", "csv", "json", "log", "xml", "html", "htm"]
        let data = try Data(contentsOf: url)
        guard data.count <= 12 * 1024 * 1024 else { throw OrbitError.message("\(url.lastPathComponent) is larger than 12 MB.") }
        if imageTypes.contains(ext) {
            let mime = ext == "jpg" ? "image/jpeg" : "image/\(ext)"
            return OrbitAttachment(name: url.lastPathComponent, mimeType: mime, base64: data.base64EncodedString())
        }
        if textTypes.contains(ext) {
            let text = String(data: data, encoding: .utf8) ?? String(data: data, encoding: .utf16) ?? ""
            guard !text.isEmpty else { throw OrbitError.message("Could not read text from \(url.lastPathComponent).") }
            return OrbitAttachment(name: url.lastPathComponent, mimeType: "text/plain", extractedText: String(text.prefix(200_000)))
        }
        if ext == "pdf", let pdf = PDFDocument(url: url) {
            let text = (0..<min(pdf.pageCount, 100)).compactMap { pdf.page(at: $0)?.string }.joined(separator: "\n")
            return OrbitAttachment(name: url.lastPathComponent, mimeType: "application/pdf", extractedText: String(text.prefix(200_000)))
        }
        throw OrbitError.message("Supported files: PNG, JPEG, WEBP, TXT, MD, CSV, JSON, LOG, XML, HTML, and text-based PDF.")
    }

    private func persist() {
        do { let data = try JSONEncoder().encode(conversations); try data.write(to: fileURL, options: .atomic) }
        catch { errorMessage = "Could not save chat history: \(error.localizedDescription)" }
    }

    private func loadConversations() {
        guard let data = try? Data(contentsOf: fileURL), let saved = try? JSONDecoder().decode([OrbitConversation].self, from: data) else { return }
        conversations = saved.sorted(by: { $0.updatedAt > $1.updatedAt })
    }

    func startVoice() {
        guard provider == "openai" else { errorMessage = "Live voice needs the OpenAI API provider."; return }
        guard !apiKey.isEmpty else { errorMessage = "Add an OpenAI API key in Settings first."; return }
        guard voice == nil else { stopVoice(); return }
        let conversationContext = activeConversation?.messages.suffix(12).map { "\($0.role): \($0.text)" }.joined(separator: "\n") ?? ""
        let instructions = systemPrompt + " Be natural and conversational. Voice mode has no computer-control tools; never claim that you performed an action. Recent chat context:\n" + String(conversationContext.suffix(7000))
        let service = RealtimeVoiceService(apiKey: apiKey, instructions: instructions)
        voice = service
        service.onStatus = { [weak self] message in DispatchQueue.main.async { self?.voiceStatus = message } }
        service.onUserTranscript = { [weak self] message in DispatchQueue.main.async { if let id = self?.activeConversationID { self?.append(OrbitMessage(role: "user", text: message), to: id) } } }
        service.onAssistantTranscript = { [weak self] message in DispatchQueue.main.async { if let id = self?.activeConversationID { self?.append(OrbitMessage(role: "assistant", text: message), to: id) } } }
        service.onError = { [weak self] message in DispatchQueue.main.async { self?.stopVoice(); self?.errorMessage = message } }
        service.start()
    }

    func stopVoice() {
        voice?.stop()
        voice = nil
        voiceStatus = ""
    }
}

enum OrbitError: LocalizedError {
    case message(String)
    var errorDescription: String? { if case .message(let text) = self { return text }; return nil }
}

private enum KeychainStore {
    private static let service = "com.archieprojectmaster.OrbitAssistant"
    static func read() -> String? {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "openai-api-key", kSecReturnData as String: true, kSecMatchLimit as String: kSecMatchLimitOne]
        var result: CFTypeRef?
        guard SecItemCopyMatching(query as CFDictionary, &result) == errSecSuccess, let data = result as? Data else { return nil }
        return String(data: data, encoding: .utf8)
    }
    static func write(_ value: String) {
        let query: [String: Any] = [kSecClass as String: kSecClassGenericPassword, kSecAttrService as String: service, kSecAttrAccount as String: "openai-api-key"]
        SecItemDelete(query as CFDictionary)
        guard !value.isEmpty else { return }
        var item = query
        item[kSecValueData as String] = Data(value.utf8)
        SecItemAdd(item as CFDictionary, nil)
    }
}
