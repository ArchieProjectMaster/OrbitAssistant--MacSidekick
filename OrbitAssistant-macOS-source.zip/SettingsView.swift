import SwiftUI

struct SettingsView: View {
    @ObservedObject var model: OrbitModel
    @Environment(\.presentationMode) private var presentationMode

    var body: some View {
        VStack(alignment: .leading, spacing: 14) {
            Text("Settings").font(.system(size: 22)).fontWeight(.bold)
            Text("Connect Orbit and choose how it looks.").font(.subheadline).foregroundColor(.secondary)
            Divider()

            Group {
                VStack(alignment: .leading, spacing: 5) {
                    Text("Provider").fontWeight(.semibold)
                    Picker("Provider", selection: $model.provider) {
                        Text("OpenAI API").tag("openai")
                        Text("Ollama (local)").tag("ollama")
                    }.pickerStyle(PopUpButtonPickerStyle())
                }
                VStack(alignment: .leading, spacing: 5) {
                    Text("Model").fontWeight(.semibold)
                    TextField("Model name", text: $model.modelName).textFieldStyle(RoundedBorderTextFieldStyle())
                }
                if model.provider == "openai" {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("OpenAI API key").fontWeight(.semibold)
                        SecureField("API key", text: $model.apiKey).textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                } else {
                    VStack(alignment: .leading, spacing: 5) {
                        Text("Ollama endpoint").fontWeight(.semibold)
                        TextField("http://localhost:11434/v1/chat/completions", text: $model.endpoint).textFieldStyle(RoundedBorderTextFieldStyle())
                    }
                }
                VStack(alignment: .leading, spacing: 5) {
                    Text("Theme").fontWeight(.semibold)
                    Picker("Theme", selection: $model.theme) {
                        Text("System Preference").tag("system")
                        Text("Dark Mode").tag("dark")
                        Text("Light Mode").tag("light")
                    }.pickerStyle(PopUpButtonPickerStyle())
                }
            }

            Text("Voice uses OpenAI Realtime and streams microphone audio while active. API use may incur charges; ChatGPT subscriptions and API billing are separate.")
                .font(.caption).foregroundColor(.secondary).fixedSize(horizontal: false, vertical: true)
            Spacer(minLength: 0)
            HStack {
                Spacer()
                Button("Cancel") { presentationMode.wrappedValue.dismiss() }
                Button("Save") { model.saveSettings(); presentationMode.wrappedValue.dismiss() }
            }
        }
        .padding(22)
        .frame(width: 440, height: 480)
    }
}
