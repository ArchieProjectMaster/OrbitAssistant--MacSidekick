import AVFoundation
import Foundation

final class RealtimeVoiceService {
    var onStatus: ((String) -> Void)?
    var onUserTranscript: ((String) -> Void)?
    var onAssistantTranscript: ((String) -> Void)?
    var onError: ((String) -> Void)?

    private let apiKey: String
    private let instructions: String
    private let engine = AVAudioEngine()
    private let player = AVAudioPlayerNode()
    private let outputFormat = AVAudioFormat(commonFormat: .pcmFormatInt16, sampleRate: 24000, channels: 1, interleaved: false)!
    private let audioSendQueue = DispatchQueue(label: "OrbitAssistant.voice-audio-send")
    private var socket: URLSessionWebSocketTask?
    private var converter: AVAudioConverter?
    private var didStartAudio = false
    private var stopped = false
    private var assistantText = ""

    init(apiKey: String, instructions: String) {
        self.apiKey = apiKey
        self.instructions = instructions
        engine.attach(player)
        engine.connect(player, to: engine.mainMixerNode, format: outputFormat)
    }

    func start() {
        guard let url = URL(string: "wss://api.openai.com/v1/realtime?model=gpt-realtime-2.1") else {
            onError?("The OpenAI Realtime URL is invalid.")
            return
        }
        var request = URLRequest(url: url)
        request.setValue("Bearer \(apiKey)", forHTTPHeaderField: "Authorization")
        let task = URLSession.shared.webSocketTask(with: request)
        socket = task
        onStatus?("Connecting to OpenAI voice…")
        task.resume()
        receiveNext()
    }

    private func receiveNext() {
        guard !stopped, let task = socket else { return }
        task.receive { [weak self] result in
            guard let self = self, !self.stopped else { return }
            switch result {
            case .failure(let error):
                self.onError?("Realtime connection error: \(error.localizedDescription)")
            case .success(let message):
                let data: Data
                switch message {
                case .string(let text): data = Data(text.utf8)
                case .data(let bytes): data = bytes
                @unknown default: data = Data()
                }
                self.handle(data)
                self.receiveNext()
            }
        }
    }

    private func handle(_ data: Data) {
        guard let event = (try? JSONSerialization.jsonObject(with: data)) as? [String: Any],
              let type = event["type"] as? String else { return }
        switch type {
        case "session.created":
            send([
                "type": "session.update",
                "session": [
                    "type": "realtime",
                    "instructions": instructions,
                    "output_modalities": ["audio"],
                    "audio": [
                        "input": [
                            "format": ["type": "audio/pcm", "rate": 24000],
                            "noise_reduction": ["type": "near_field"],
                            "transcription": ["model": "gpt-4o-mini-transcribe"],
                            "turn_detection": ["type": "server_vad", "threshold": 0.5, "prefix_padding_ms": 300, "silence_duration_ms": 500, "create_response": true, "interrupt_response": true]
                        ],
                        "output": ["format": ["type": "audio/pcm", "rate": 24000], "voice": "marin"]
                    ]
                ]
            ])
            onStatus?("Configuring voice…")
        case "session.updated":
            if !didStartAudio { startAudio() }
        case "input_audio_buffer.speech_started":
            player.stop()
            onStatus?("Listening…")
        case "input_audio_buffer.speech_stopped", "response.created":
            onStatus?("Orbit is replying…")
        case "conversation.item.input_audio_transcription.completed":
            if let transcript = event["transcript"] as? String, !transcript.isEmpty { onUserTranscript?(transcript) }
        case "response.audio.delta":
            if let encoded = event["delta"] as? String, let audio = Data(base64Encoded: encoded) { play(audio) }
        case "response.audio_transcript.delta":
            assistantText += (event["delta"] as? String) ?? ""
        case "response.audio_transcript.done":
            let transcript = (event["transcript"] as? String) ?? assistantText
            if !transcript.isEmpty { onAssistantTranscript?(transcript) }
            assistantText = ""
        case "response.done", "response.audio.done":
            onStatus?("Listening · speak naturally")
        case "error":
            let errorObject = event["error"] as? [String: Any]
            onError?((errorObject?["message"] as? String) ?? "OpenAI returned a Realtime API error.")
        default: break
        }
    }

    private func send(_ event: [String: Any]) {
        guard let task = socket, let data = try? JSONSerialization.data(withJSONObject: event),
              let string = String(data: data, encoding: .utf8) else { return }
        task.send(.string(string)) { [weak self] error in
            if let error = error, self?.stopped == false { self?.onError?("Could not send audio to OpenAI: \(error.localizedDescription)") }
        }
    }

    private func startAudio() {
        guard !didStartAudio else { return }
        do {
            let input = engine.inputNode
            let inputFormat = input.outputFormat(forBus: 0)
            guard inputFormat.sampleRate > 0, let audioConverter = AVAudioConverter(from: inputFormat, to: outputFormat) else {
                onError?("Could not initialize the selected microphone audio format.")
                return
            }
            converter = audioConverter
            input.installTap(onBus: 0, bufferSize: 1024, format: inputFormat) { [weak self] buffer, _ in
                self?.sendMicrophoneBuffer(buffer, inputFormat: inputFormat)
            }
            try engine.start()
            player.play()
            didStartAudio = true
            onStatus?("Listening · speak naturally")
        } catch {
            onError?("Could not start microphone audio: \(error.localizedDescription). Check System Settings → Privacy & Security → Microphone.")
        }
    }

    private func sendMicrophoneBuffer(_ input: AVAudioPCMBuffer, inputFormat: AVAudioFormat) {
        guard let converter = converter, let output = AVAudioPCMBuffer(pcmFormat: outputFormat, frameCapacity: AVAudioFrameCount(Double(input.frameLength) * 24000.0 / inputFormat.sampleRate + 8)) else { return }
        var conversionError: NSError?
        var suppliedInput = false
        converter.convert(to: output, error: &conversionError) { _, status in
            if suppliedInput { status.pointee = .noDataNow; return nil }
            suppliedInput = true
            status.pointee = .haveData
            return input
        }
        if let conversionError = conversionError { onError?("Microphone audio conversion failed: \(conversionError.localizedDescription)"); return }
        guard output.frameLength > 0, let samples = output.int16ChannelData?[0] else { return }
        let audio = Data(bytes: samples, count: Int(output.frameLength) * MemoryLayout<Int16>.size)
        audioSendQueue.async { [weak self] in
            guard let self = self, !self.stopped else { return }
            self.send(["type": "input_audio_buffer.append", "audio": audio.base64EncodedString()])
        }
    }

    private func play(_ data: Data) {
        let frameCount = AVAudioFrameCount(data.count / MemoryLayout<Int16>.size)
        guard frameCount > 0, let buffer = AVAudioPCMBuffer(pcmFormat: outputFormat, frameCapacity: frameCount),
              let samples = buffer.int16ChannelData?[0] else { return }
        buffer.frameLength = frameCount
        data.withUnsafeBytes { rawBuffer in
            if let source = rawBuffer.bindMemory(to: Int16.self).baseAddress {
                samples.initialize(from: source, count: Int(frameCount))
            }
        }
        player.scheduleBuffer(buffer, completionHandler: nil)
        if !player.isPlaying { player.play() }
    }

    func stop() {
        guard !stopped else { return }
        stopped = true
        if didStartAudio {
            engine.inputNode.removeTap(onBus: 0)
            player.stop()
            engine.stop()
        }
        socket?.cancel(with: .normalClosure, reason: nil)
        socket = nil
    }
}
