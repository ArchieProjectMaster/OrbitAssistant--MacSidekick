# Orbit Assistant for macOS

Orbit Assistant for macOS is a separate native SwiftUI desktop app for macOS Catalina (10.15) and later. It provides AI chat, local conversation history, image and document attachments, theme choices, OpenAI Realtime voice, and a local Ollama option.

## Features

- Native macOS window with standard close, minimize, and resize controls.
- OpenAI-compatible chat API and local Ollama chat endpoint.
- Conversation list and local chat persistence.
- Image understanding for PNG, JPEG, and WebP attachments.
- Text extraction from TXT, Markdown, CSV, JSON, LOG, XML, HTML, and text-based PDF files.
- Dark, light, and system appearance choices.
- OpenAI Realtime voice chat with microphone capture and spoken responses.
- Voice uses the Mac’s current default input and output devices. Microphone access is requested by macOS when voice starts.
- Small local commands: `/help`, `/open safari`, `/open notes`, `/open calculator`, `/system`, and `/web search terms`.

## Requirements

- macOS 10.15 Catalina or later.
- OpenAI API key for OpenAI chat and live voice, or Ollama running locally for text chat.
- A network connection for OpenAI API and web searches. Ollama chat can run locally.

Live voice uses OpenAI's Realtime API and sends microphone audio while voice mode is active. It has separate API usage charges from ChatGPT. Voice is not available through the local Ollama provider.

## Download a prebuilt app

The GitHub Actions workflow in `.github/workflows/build-macos.yml` builds the app on an Apple macOS runner. To get the compiled app, put the contents of this folder at the root of a GitHub repository and push to `main` (or `master`), or run the workflow manually from the repository's **Actions** tab. When the run finishes, open it and download the `OrbitAssistant-macOS` artifact. Extract the ZIP and move `Orbit Assistant.app` to Applications.

This workflow creates an unsigned app. On first launch, macOS may block it because it is not notarized. Control-click the app, choose **Open**, then confirm. The build artifact is available for 30 days.

## Build and run from source

Build this native macOS app on a Mac with Xcode installed:

1. Open `OrbitAssistant.xcodeproj` in Xcode.
2. Select the `OrbitAssistant` scheme and a Mac destination.
3. Choose **Product → Run**.

The project sets its deployment target to macOS 10.15 and uses the AppKit application lifecycle with SwiftUI hosted in a resizable native window. Catalina-compatible `ObservableObject`/`ObservedObject` state management is used instead of newer SwiftUI app-lifecycle APIs. No external packages are required.

For a command-line build on a Mac:

```sh
xcodebuild -project OrbitAssistant.xcodeproj -scheme OrbitAssistant -configuration Release -destination 'platform=macOS' -derivedDataPath build build
```

The build output is `build/Build/Products/Release/OrbitAssistant.app`.

## First launch

1. Open Orbit Assistant.
2. Choose **Settings** in the left sidebar.
3. Select **OpenAI API** or **Ollama (local)**.
4. For OpenAI, enter an API key and a model enabled for your API project. ChatGPT subscriptions and API billing are separate.
5. For Ollama, start Ollama and enter the model name and endpoint. The default endpoint is `http://localhost:11434/v1/chat/completions`.
6. Save, then start a chat. Click the microphone button for live voice when OpenAI is selected.

## Attachments and limits

Use the paperclip button to select image or text/document files. Orbit accepts up to 10 files and 20 MB total, with a 12 MB maximum for one file. Extracted document text is limited to 200,000 characters per message. PDF extraction reads up to 100 pages. Scanned PDFs are not OCR processed. Attach an image directly when you want visual analysis.

When a message with attachments is sent, its text, images, and extracted document text are sent to the provider selected in Settings. Attached content is also kept in the local conversation history.

## History and settings storage

- Conversations: `~/Library/Application Support/OrbitAssistant/chats.json`
- Provider, model, endpoint, and theme: macOS preferences (`UserDefaults`)
- OpenAI API key: macOS Keychain

## Compatibility notes

SwiftUI's newer `App` lifecycle and newer convenience controls are not used because they are unavailable on Catalina. The app uses an AppKit `NSApplication` delegate and `NSHostingView` to host the SwiftUI interface, and uses a native `NSOpenPanel` for file selection. Standard macOS window controls provide resizing and minimize/close behavior.

## Known limitations

- This project is a macOS port and stores data separately from the Windows Orbit Assistant installation.
- Voice mode does not invoke desktop actions. Use text chat for questions or commands that need app/file interaction.
- Voice model availability and charges depend on the OpenAI API project.
- The source project requires a Mac and Xcode to build and run. It cannot be compiled into a macOS application on Windows.
- The project has not been code-signed or notarized for distribution.

## License

MIT. See [LICENSE](LICENSE).
